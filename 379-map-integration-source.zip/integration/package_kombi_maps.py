"""Pin the published renderer binaries; build a Studio-only optional feature."""
from pathlib import Path
import hashlib, io, json, struct, tarfile, urllib.request, subprocess, re

BASE=Path(__file__).resolve().parent
OUT=BASE/'kyles-mgu-flasher/payload/apps'
CATALOG=json.loads((BASE/'carplay-cluster-reference-catalog.json').read_text())
def sha(data): return hashlib.sha256(data).hexdigest()
files={}
origins=[]
for id in ('cluster-render','waze-on-cluster'):
    c=next(c for c in CATALOG['components'] if c['id']==id)
    a=c['artifact']
    cache=BASE/a['name']
    if not cache.exists(): urllib.request.urlretrieve(a['url'],cache)
    blob=cache.read_bytes()
    assert len(blob)==a['size'] and sha(blob)==a['sha256'],id
    origins.append(c)
    with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz') as t:
        meta=json.load(t.extractfile('component.json'))
        names=[id,id+'.conf']+(['cluster_render_client.js'] if id=='cluster-render' else [])
        for name in names:
            data=t.extractfile('files/'+name).read()
            assert sha(data)==next(f['sha256'] for f in meta['files'] if f['path']==name)
            files[f'native/{id}/{name}']=data
        for suffix in ('socket','service'):
            name=id+'.'+suffix
            files['units/'+name]=t.extractfile('units/'+name).read()
        if id=='waze-on-cluster':
            files['reference/carplay_patch.js']=t.extractfile('files/carplay_patch.js').read()

# Constrain this feature to the background map slot. The renderer's general
# whole-panel/HUD targets must not be available to this dedicated integration.
def config_value(blob,key,value):
    text,count=re.subn(r'^'+re.escape(key)+r'\s*=.*$',key+' = '+value,blob.decode(),flags=re.M)
    if count!=1:raise ValueError('Unexpected upstream configuration: '+key)
    return text.encode()
for id in ('cluster-render','waze-on-cluster'):
    name=f'native/{id}/{id}.conf'
    files[name]=config_value(files[name],'local_conf','')
name='native/cluster-render/cluster-render.conf'
files[name]=config_value(files[name],'targets','map')
files[name]=config_value(files[name],'scene_ids_allowed','0x010004f0')
# A parked Apple Maps route can repeat a valid picture at video frame rate.
# Image equality alone must not hide the map. Keep the native connection and
# decoded-frame timeouts; this does not prove that a repeated image is current.
name='native/waze-on-cluster/waze-on-cluster.conf'
files[name]=config_value(files[name],'freeze_ms','0')
files[name]+=b'\n# 379: repeated pictures do not imply a disconnected stream.\n# Connection loss and idle_ms still release the map layer.\n'
layout={'target':'map','slot':'0x100','wholePanelEnabled':False,'hudEnabled':False,
        'preserve':['speedometer','tachometer','drive mode','gear','temperature','fuel','range and consumption','warning indicators'],
        'factoryDirectionOverlay':'not suppressed; requires vehicle verification',
        'duplicateSpeedReadout':'not suppressed; requires vehicle verification'}

# Corresponding source for the exact catalog commit accompanies the native code.
source=BASE/('idrive-apps-'+CATALOG['commit']+'.tar.gz')
if not source.exists(): urllib.request.urlretrieve('https://codeload.github.com/robertnisipeanu/idrive-apps/tar.gz/'+CATALOG['commit'],source)
files['sources/idrive-apps.tar.gz']=source.read_bytes()
files['LICENSE.txt']=(BASE/'carplay-cluster-reference/LICENSE').read_bytes()
files['NOTICE.txt']=(
    'Apple Maps in KOMBI — Studio integration.\n'
    'Renderer and CarPlay patch research: Robert Nisipeanu / idrive-apps.\n'
    'https://github.com/robertnisipeanu/idrive-apps\n'
    'GPL-3.0-or-later; third-party notices and corresponding source included.\n'
    'Native binaries are unchanged published releases. Studio installs only the map\n'
    'renderer/capture services, applies the pinned patch after a verified PC backup,\n'
    'and requires a manual HU reboot. No Store, updater, patch daemon or other apps.\n'
    'Studio restricts renderer configuration to the background map target only.\n'
    'Factory turn cards and the duplicate speed readout are not automatically hidden.\n'
    'Apple Maps is supplied by the connected iPhone, not included in this package.\n'
).encode()
def pair(a,b): return struct.pack('<II',a,b)
regions=[
    (0x2ba4f0,struct.pack('<I',0xfff7f2ec),struct.pack('<I',0xfff7f2bc)),
    (0x18176c,bytes.fromhex('e8effdffff'),bytes.fromhex('e89f000000')),
    (0x20ca32,pair(234,110),pair(138,61)),
    (0x20ca54,pair(1920,900),pair(1088,480)),
    (0x20ca66,struct.pack('<HHI',0,0,612),struct.pack('<HHI',0,0,504)),
    (0x20ca74,struct.pack('<IHH',526,514,192),struct.pack('<IHH',368,286,72)),
]
manifest={'schema':1,'sourceCommit':CATALOG['commit'],'artifacts':origins,
    'originalSha256':'ddb33e33161387c6479c391684b3d019b0de54ecfcee8d6877eca94aa62f3e50',
    'originalSize':3484912,'carplayVersion':'22.28.3','target':'map','mapSize':[1088,480],
    'regions':[{'offset':o,'before':a.hex(),'after':b.hex()} for o,a,b in regions], 'layout':layout,
    'files':{p:sha(b) for p,b in files.items()}}
files['feature.json']=json.dumps(manifest,indent=2).encode()
item={'id':'apple_maps_kombi','title':'Apple Maps in KOMBI','version':'0.1.2',
      'kind':'feature','default_selected':False,
      'description':'Background map only; BMW instruments retained. Factory direction/speed overlays still need verification.',
      'filename':'apple_maps_kombi@0.1.2.mgu'}
files['meta.json']=json.dumps({k:item[k] for k in ('id','title','version')}).encode()
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w:gz') as t:
    for name,data in sorted(files.items()):
        ent=tarfile.TarInfo(name); ent.size=len(data); ent.mode=0o644
        t.addfile(ent,io.BytesIO(data))
OUT.mkdir(parents=True,exist_ok=True)
(OUT/item['filename']).write_bytes(buf.getvalue())
item['sha256']=sha(buf.getvalue())
cat=OUT.parent/'catalog.json'
items=[i for i in json.loads(cat.read_text()) if i['id']!=item['id']]+[item]
cat.write_text(json.dumps(items,indent=2),encoding='utf-8')
print('Packaged',item['title'],len(buf.getvalue()),'bytes;',item['sha256'])
