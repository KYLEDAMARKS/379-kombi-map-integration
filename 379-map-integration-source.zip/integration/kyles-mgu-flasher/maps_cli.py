"""Map-only console entry point. Does not flash or enroll a head unit."""
import argparse
from pathlib import Path
import kombi_maps

def main():
    p=argparse.ArgumentParser()
    p.add_argument('action',choices=['check','install','remove'])
    p.add_argument('--host',required=True)
    p.add_argument('--port',type=int,default=22)
    p.add_argument('--key',required=True,help='Existing authorized SSH key file; never upload this file')
    a=p.parse_args(); root=Path(__file__).resolve().parent
    log=lambda s:print(s,end='')
    approve=lambda message:input(message+'\nTrust this verified host key? Type yes: ').strip()=='yes'
    if a.action=='remove': kombi_maps.remove(root,a.host,a.port,a.key,approve,log)
    else:
        checked=kombi_maps.check(root,a.host,a.port,a.key,approve,log)
        if a.action=='install':kombi_maps.install(root,checked,log)
        else: print('Map compatibility check completed. No map files changed.')
if __name__=='__main__':main()
