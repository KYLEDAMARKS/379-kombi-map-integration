"""Optional CarPlay map integration. Firmware edits are prepared and backed up on PC.

No vehicle operation runs when importing this module. Native services start only
at the owner's next HU reboot; the CarPlay process is never killed or restarted.
"""
from pathlib import Path
import hashlib
import io
import json
import shlex
import tarfile
import uuid
import re

from mod_package import app_data, selection

ID='apple_maps_kombi'
CONFIG_UPDATABLE_BUNDLES={'8e2a0f61b78d4c561bb039284ba0731cf03859a30be13bb3edb7c78258f5a44d'}
LEGACY_BUNDLES={'2e3a09d4b612f3c71fa5019d101598fe27fbd777e999ddc65366e6f84ceae867'} | CONFIG_UPDATABLE_BUNDLES
STATE='/var/opt/kyles-maps-kombi/state.json'
CARPLAY='/usr/bin/carplay'
LISTS=('/etc/recmgr-restartlist.conf','/etc/crashhandler-restartlist.conf')
VERSIONS={'cluster-render':'0.2.0','waze-on-cluster':'0.6.0'}
CAPTURE_CONFIG='/var/opt/waze-on-cluster/versions/0.6.0/waze-on-cluster.conf'
UNITS=[id+'.'+suffix for id in VERSIONS for suffix in ('socket','service')]

def sha(data): return hashlib.sha256(data).hexdigest()

def payload(root):
    item=selection(root,[ID])[0]
    with tarfile.open(fileobj=io.BytesIO(app_data(root,item)),mode='r:gz') as t:
        files={e.name:t.extractfile(e).read() for e in t if e.isfile()}
    m=json.loads(files['feature.json'])
    for name,digest in m['files'].items():
        if sha(files[name])!=digest: raise ValueError('Map component checksum failed: '+name)
    validate_layout(files)
    return m,files

def validate_layout(files):
    def config(id):
        text=files['native/'+id+'/'+id+'.conf'].decode()
        result={}
        for line in text.splitlines():
            if '=' not in line or line.lstrip().startswith('#'):continue
            key,value=(part.strip() for part in line.split('=',1))
            if not key or key in result:raise ValueError('Ambiguous map configuration')
            result[key]=value
        return result
    render=config('cluster-render');capture=config('waze-on-cluster')
    required={'targets':'map','scene_ids_allowed':'0x010004f0','map_slot':'0x100','map_scene_id':'0x010004f0','map_size':'1088x480','local_conf':''}
    if any(render.get(k)!=v for k,v in required.items()) or capture.get('target')!='map' or capture.get('local_conf')!='':
        raise ValueError('Map package must use only the background map layer; panel/HUD targets and local overrides are not allowed.')

def targets(files):
    result={}
    for name,data in files.items():
        if name.startswith('native/'):
            _,id,filename=name.split('/')
            result['/var/opt/'+id+'/versions/'+VERSIONS[id]+'/'+filename]=(data,0o755 if filename==id else 0o644)
        elif name.startswith('units/'):
            result['/etc/systemd/system/'+name.split('/')[1]]=(data,0o644)
    return result

def links():
    out={'/var/opt/'+id+'/current':'versions/'+version for id,version in VERSIONS.items()}
    for id in VERSIONS:
        out['/etc/systemd/system/sockets.target.wants/'+id+'.socket']='../'+id+'.socket'
    out['/etc/systemd/system/multi-user.target.wants/waze-on-cluster.service']='../waze-on-cluster.service'
    return out

PROBE=r'''
const fs=require('fs'),crypto=require('crypto'),cp=require('child_process');
function read(p){try{return fs.readFileSync(p,'utf8');}catch(e){return '';}}
function info(p){try{const s=fs.lstatSync(p);if(s.isSymbolicLink())return {kind:'link',target:fs.readlinkSync(p)};
 if(!s.isFile())return {kind:'other'};return {kind:'file',sha256:crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'),mode:s.mode&4095,uid:s.uid,gid:s.gid};
 }catch(e){if(e.code==='ENOENT')return {kind:'absent'};throw e;}}
const paths=JSON.parse(process.argv[2]),out={paths:{},boot:read('/proc/sys/kernel/random/boot_id').trim(),arch:process.arch,root:process.getuid()===0,
 node:process.versions.node,groups:read('/etc/group'),gpu:fs.existsSync('/dev/dri/renderD128'),state:read('/var/opt/kyles-maps-kombi/state.json'),lists:{},owners:{}};
paths.forEach(p=>out.paths[p]=info(p));
['/etc/recmgr-restartlist.conf','/etc/crashhandler-restartlist.conf'].forEach(p=>out.lists[p]=read(p));
['cluster-render','waze-on-cluster'].forEach(id=>out.owners[id]=fs.existsSync('/var/opt/'+id));
process.stdout.write(JSON.stringify(out));
'''

def patch_binary(blob, manifest):
    if len(blob)!=manifest['originalSize'] or sha(blob)!=manifest['originalSha256']:
        raise ValueError('Unsupported CarPlay binary. No firmware changes made.')
    out=bytearray(blob)
    for r in manifest['regions']:
        off=r['offset']; before=bytes.fromhex(r['before']); after=bytes.fromhex(r['after'])
        if len(before)!=len(after) or blob[off:off+len(before)]!=before:
            raise ValueError('CarPlay patch anchor mismatch')
        out[off:off+len(after)]=after
    return bytes(out)

def edit_list(text, sections, add=(), remove=()):
    """Preserve other sections and names. Used only for our two service names."""
    lines=text.splitlines(); out=[]; section=None; seen=set(); present=set()
    def finish():
        if section in sections:
            out.extend(n for n in add if n not in seen)
    for line in lines:
        stripped=line.strip()
        if stripped.startswith('[') and stripped.endswith(']'):
            finish(); section=stripped[1:-1]; present.add(section); seen=set()
        elif section in sections:
            if stripped in remove: continue
            seen.add(stripped)
        out.append(line)
    finish()
    for sec in sections:
        if sec not in present: out+=['['+sec+']']+list(add)
    return '\n'.join(out)+'\n'

def check(root,host,port,key,approve,log):
    import mod_install
    manifest,files=payload(root)
    known=mod_install.trust_host(root,host,port,approve,log)
    paths=[CARPLAY,STATE,*LISTS,*targets(files),*links()]
    raw=mod_install.ssh(host,port,key,known,'/usr/bin/node - '+shlex.quote(json.dumps(paths)),data=PROBE.encode(),timeout=40)
    facts=json.loads(raw)
    if not facts['root'] or facts['arch']!='x64' or not facts['gpu']:
        raise ValueError('Apple Maps in KOMBI needs an ID7 x64 MGU with its graphics device and root SSH.')
    for group in ('hmi_5000','mgu_ufipc','tm_oap_app','video'):
        if not any(l.startswith(group+':') for l in facts['groups'].splitlines()):
            raise ValueError('Required HU group is missing: '+group)
    for p in (CARPLAY,*LISTS):
        if facts['paths'][p]['kind']!='file': raise ValueError('Unsupported HU file layout: '+p)
    state=json.loads(facts['state']) if facts['state'] else None
    current=facts['paths'][CARPLAY]['sha256']
    if state:
        accepted=LEGACY_BUNDLES|{selection(root,[ID])[0]['sha256']}
        if state.get('owner')!=ID or state.get('bundle') not in accepted or current!=state.get('patchedSha256'):
            raise ValueError('Existing map installation or CarPlay firmware differs. No files changed.')
        expected_paths={CARPLAY,*LISTS,*targets(files),*links()}
        if set(state.get('installed',{}))!=expected_paths or not re.fullmatch(r'[A-Za-z0-9_-]{1,100}',state.get('backupId','')):
            raise ValueError('Invalid map installation record')
        for p,expected in state['installed'].items():
            actual=facts['paths'].get(p)
            if actual!=expected: raise ValueError('Installed map component changed: '+p)
        log('Apple Maps in KOMBI '+state['version']+' is installed. Factory center overlays have not been verified as hidden.\n')
    else:
        if current!=manifest['originalSha256']:
            raise ValueError('Apple Maps in KOMBI is not compatible with this CarPlay binary. Supported: '+manifest['carplayVersion']+
                             '. Detected SHA256: '+current+'. No firmware changes made.')
        if any(facts['owners'].values()):
            raise ValueError('Cluster map components already exist outside Studio. Refusing to overwrite them.')
        for p in [STATE,*targets(files),*links()]:
            if facts['paths'][p]['kind']!='absent': raise ValueError('Map installation path is already occupied: '+p)
        log('Apple Maps in KOMBI: supported CarPlay '+manifest['carplayVersion']+' verified. Background map slot only, 1088 × 480.\n'
            'BMW gauges and vehicle indicators remain in their native layers. Factory direction cards and duplicate speed are not automatically hidden.\n')
    return dict(host=host,port=port,key=key,known=str(known),facts=facts,state=state,bundle=selection(root,[ID])[0]['sha256'])

# The target list is generated locally from the pinned payload. Every before-state
# is rechecked, all staged checksums are verified, then writes use atomic rename.
# No backup copy is created on the HU. A failure reports the exact changed paths.
APPLY=r'''
const fs=require('fs'),path=require('path'),crypto=require('crypto'),cp=require('child_process');
const plan=JSON.parse(fs.readFileSync('plan.json','utf8'));
const allowed=new Set(plan.allowed),changed=[];
function hash(b){return crypto.createHash('sha256').update(b).digest('hex');}
function info(p){try{const s=fs.lstatSync(p);if(s.isSymbolicLink())return {kind:'link',target:fs.readlinkSync(p)};
 if(!s.isFile())return {kind:'other'};return {kind:'file',sha256:hash(fs.readFileSync(p)),mode:s.mode&4095,uid:s.uid,gid:s.gid};
 }catch(e){if(e.code==='ENOENT')return {kind:'absent'};throw e;}}
function parents(p){for(let d=path.dirname(p);d!=='/';d=path.dirname(d)){try{let s=fs.lstatSync(d);if(!s.isDirectory()||s.isSymbolicLink())throw Error('Unsafe parent '+d);}catch(e){if(e.code!=='ENOENT')throw e;}}}
function mkdir(p){if(fs.existsSync(p))return;mkdir(path.dirname(p));fs.mkdirSync(p,493);fs.chmodSync(p,493);}
function run(cmd,args){return cp.execFileSync(cmd,args,{encoding:'utf8',timeout:15000});}
function checkNative(file){
 const b=fs.readFileSync(file);
 if(b.length<64||b.toString('hex',0,4)!=='7f454c46'||b[4]!==2||b[5]!==1||b.readUInt16LE(18)!==62)throw Error('Expected an x64 ELF native component');
 function u64(o){const n=b.readUInt32LE(o)+b.readUInt32LE(o+4)*4294967296;if(!Number.isSafeInteger(n))throw Error('Invalid ELF offset');return n;}
 const start=u64(32),stride=b.readUInt16LE(54),count=b.readUInt16LE(56);let loader='';
 if(stride<56||count<1||count>128||start+stride*count>b.length)throw Error('Invalid ELF program headers');
 for(let i=0;i<count;i++){
  const h=start+i*stride;if(b.readUInt32LE(h)!==3)continue;
  const off=u64(h+8),size=u64(h+32);
  if(loader||size<2||size>256||off+size>b.length||b[off+size-1]!==0)throw Error('Invalid ELF interpreter');
  loader=b.toString('ascii',off,off+size-1);
 }
 // Use the pinned binary's system ELF interpreter in listing mode only. This
 // checks transitive dependencies without starting the program or its services.
 if(!['/lib/ld-linux-x86-64.so.2','/lib64/ld-linux-x86-64.so.2'].includes(loader))throw Error('Unsupported native ELF interpreter: '+loader);
 if(!fs.existsSync(loader))throw Error('Native ELF loader is missing: '+loader);
 let text;
 try{text=run(loader,['--list',path.resolve(file)]);}
 catch(e){throw Error('Native dependency check failed: '+String(e.stderr||e.stdout||e.message).slice(0,1500));}
 if(/not found|error while loading shared libraries/i.test(text))throw Error('Missing native library: '+text);
 process.stdout.write('Native dependencies verified with '+loader+' --list\n');
}
let locked=false,wasRO=false,remounted=false;
try {
 if(process.getuid()!==0)throw Error('Root required');
 const lock=fs.openSync('/tmp/studio-kombi-maps.lock','wx',384);fs.closeSync(lock);locked=true;
 if(fs.readFileSync('/proc/sys/kernel/random/boot_id','utf8').trim()!==plan.boot)throw Error('HU rebooted; check again');
 const seen=new Set();
 plan.ops.forEach(o=>{if(!allowed.has(o.path)||seen.has(o.path))throw Error('Invalid target');seen.add(o.path);parents(o.path);
  if(JSON.stringify(info(o.path))!==JSON.stringify(o.before))throw Error('File changed: '+o.path);
  if(o.src){if(!/^data\/[0-9]+$/.test(o.src)||hash(fs.readFileSync(o.src))!==o.after.sha256)throw Error('Staged checksum failed');}
 });
 if(plan.carplayHash!==info('/usr/bin/carplay').sha256)throw Error('CarPlay changed since PC backup');
 if(plan.action==='install') {
  plan.ops.filter(o=>o.executable).forEach(o=>{fs.chmodSync(o.src,448);checkNative(o.src);});
  ['/','/var/opt','/tmp'].forEach(p=>{let rows=run('df',['-Pk',p]).trim().split('\n');let cols=rows[rows.length-1].trim().split(/\s+/);if(!(Number(cols[3])>=32768))throw Error('Need at least 32 MB free at '+p);});
 }
 const mount=fs.readFileSync('/proc/mounts','utf8').split('\n').map(l=>l.split(' ')).find(f=>f[1]==='/');
 if(!mount)throw Error('Cannot identify root mount');wasRO=mount[3].split(',').includes('ro');
 if(wasRO){run('mount',['-o','remount,rw','/']);remounted=true;}
 plan.ops.forEach(o=>{
  if(o.after.kind==='absent'){if(o.before.kind!=='absent')fs.unlinkSync(o.path);}
  else {
   mkdir(path.dirname(o.path));const tmp=o.path+'.studio-new-'+process.pid;
   if(fs.existsSync(tmp))throw Error('Stale staging file: '+tmp);
   try {
    if(o.after.kind==='link')fs.symlinkSync(o.after.target,tmp);
    else {fs.writeFileSync(tmp,fs.readFileSync(o.src),{mode:o.after.mode,flag:'wx'});fs.chmodSync(tmp,o.after.mode);fs.chownSync(tmp,o.after.uid,o.after.gid);const fd=fs.openSync(tmp,'r');try{fs.fsyncSync(fd);}finally{fs.closeSync(fd);}}
    fs.renameSync(tmp,o.path);
   } finally {try{fs.unlinkSync(tmp);}catch(e){if(e.code!=='ENOENT')throw e;}}
  }
  changed.push(o.path);
  if(JSON.stringify(info(o.path))!==JSON.stringify(o.after))throw Error('Write verification failed: '+o.path);
 });
 if(plan.action==='remove') {
  ['/var/opt/cluster-render/versions/0.2.0','/var/opt/cluster-render/versions','/var/opt/cluster-render',
   '/var/opt/waze-on-cluster/versions/0.6.0','/var/opt/waze-on-cluster/versions','/var/opt/waze-on-cluster',
   '/var/opt/kyles-maps-kombi'].forEach(p=>{try{fs.rmdirSync(p);}catch(e){if(!['ENOENT','ENOTEMPTY','EEXIST'].includes(e.code))throw e;}});
 }
 run('sync',[]);
    process.stdout.write('MAPS_FILES_VERIFIED\n'+(plan.action==='configure'?'Restart the map capture service to load the configuration.':'Manual HU reboot required.')+' No services were restarted.\n');
} catch(e) {process.stderr.write('Map operation failed: '+e.message+'\nChanged paths: '+JSON.stringify(changed)+'\n'+(changed.length?'Restore the changed map files from the PC backup before retrying.\n':'No map files were replaced. No map-file restore is needed for this failure.\n'));process.exitCode=1;}
finally {if(remounted){try{run('mount',['-o','remount,ro','/']);}catch(e){process.stderr.write('Failed to restore root read-only: '+e.message);process.exitCode=1;}}if(locked)fs.unlinkSync('/tmp/studio-kombi-maps.lock');}
'''

def file_info(data,mode=0o644,uid=0,gid=0):
    return dict(kind='file',sha256=sha(data),mode=mode,uid=uid,gid=gid)

def send_plan(checked,plan,data,log):
    import mod_install
    import operation_progress
    progress=operation_progress.current()
    stage='/tmp/studio-kombi-'+uuid.uuid4().hex
    entries={'plan.json':json.dumps(plan).encode(),'apply.js':APPLY.encode(),**data}
    out=io.BytesIO()
    with tarfile.open(fileobj=out,mode='w:gz') as t:
        for name,blob in entries.items():
            e=tarfile.TarInfo(name);e.size=len(blob);e.mode=0o600;t.addfile(e,io.BytesIO(blob))
    args=[checked[k] for k in ('host','port','key','known')]
    command='umask 077; mkdir '+stage+' && tar xzf - -C '+stage+' && cd '+stage+' && /usr/bin/node apply.js'
    package=out.getvalue()
    progress.stage('Uploading map integration','Sending the checked map files; waiting for the HU to apply and verify the plan.',
                   total=len(package),unit='bytes',estimate=True,files_total=len(entries))
    result=mod_install.ssh(*args,command,data=package,timeout=180,on_line=log,
                          on_bytes=lambda count,total:progress.update(completed=count))
    if 'MAPS_FILES_VERIFIED' not in result: raise RuntimeError('Map installation was not confirmed. Read HU before retrying.')
    progress.update(files_done=len(entries),detail='Map file writes verified. '+
                    ('Restart map capture to load the configuration.' if plan['action']=='configure' else 'A manual HU reboot is still required.'))
    # Only the unique temporary staging directory created above is removed.
    mod_install.ssh(*args,'rm -rf -- '+stage,timeout=30)

def update_capture_config(root,checked,log):
    """Upgrade only the pinned capture configuration, preserving the undo backup."""
    import copy
    import pc_backup
    state=checked['state']
    if state.get('bundle') not in CONFIG_UPDATABLE_BUNDLES:
        raise ValueError('An older map integration is installed. Remove it with the original PC backup before upgrading.')
    item=selection(root,[ID])[0]
    if item['sha256']!=checked['bundle']:raise ValueError('Map package changed; check again')
    _,files=payload(root)
    facts=checked['facts']; wanted=targets(files)
    # No firmware, executables, renderer geometry, units or links may change in
    # this migration. check() already compared every installed path with its
    # recorded hash; APPLY repeats the before-state check after the PC backup.
    for p,(blob,mode) in wanted.items():
        if p!=CAPTURE_CONFIG and file_info(blob,mode)!=facts['paths'][p]:
            raise ValueError('Map update needs more than a capture configuration change: '+p)
    for p,target in links().items():
        if facts['paths'][p]!=dict(kind='link',target=target):raise ValueError('Map link changed: '+p)
    args=[checked[k] for k in ('host','port','key','known')]
    backup=pc_backup.capture(root,*args,[CAPTURE_CONFIG.lstrip('/'),STATE.lstrip('/')],log,'kombi-capture-update')
    updated=copy.deepcopy(state);data={};ops=[]
    blob,mode=wanted[CAPTURE_CONFIG]
    before=facts['paths'][CAPTURE_CONFIG]
    after=file_info(blob,mode,before['uid'],before['gid'])
    updated['installed'][CAPTURE_CONFIG]=after
    updated.update(version=item['version'],bundle=item['sha256'])
    updated['captureUpdateBackupId']=backup.name
    for p,body,attrs in ((CAPTURE_CONFIG,blob,after),
                         (STATE,json.dumps(updated,indent=2).encode(),facts['paths'][STATE])):
        src='data/'+str(len(data));data[src]=body
        ops.append(dict(path=p,before=facts['paths'][p],
                        after=file_info(body,attrs['mode'],attrs['uid'],attrs['gid']),src=src))
    plan=dict(action='configure',boot=facts['boot'],carplayHash=state['patchedSha256'],
              allowed=[CAPTURE_CONFIG,STATE],ops=ops)
    (backup/'map-capture-update-plan.json').write_text(json.dumps(plan,indent=2))
    log('Updating the map capture configuration only. Original CarPlay restore backup retained.\n')
    send_plan(checked,plan,data,log)
    log('Map capture configuration verified. Restart map capture and reconnect CarPlay to apply it.\n')


def install(root,checked,log):
    import pc_backup
    if checked['state']:
        if checked['state']['bundle']!=checked['bundle']:
            update_capture_config(root,checked,log)
        return
    m,files=payload(root)
    if selection(root,[ID])[0]['sha256']!=checked['bundle']: raise ValueError('Map package changed; check again')
    facts=checked['facts']; args=[checked[k] for k in ('host','port','key','known')]
    backup=pc_backup.capture(root,*args,[p.lstrip('/') for p in facts['paths']],log,'kombi-maps')
    with tarfile.open(backup/'files.tar','r:') as t: original=t.extractfile(CARPLAY.lstrip('/')).read()
    patched=patch_binary(original,m)
    installed={}; ops=[]; data={}
    def add(p,blob,mode,attrs=None):
        before=facts['paths'][p]; attrs=attrs or {}; after=file_info(blob,mode,attrs.get('uid',0),attrs.get('gid',0))
        src='data/'+str(len(data));data[src]=blob
        op=dict(path=p,before=before,after=after,src=src)
        if p.endswith(('/cluster-render','/waze-on-cluster')):op['executable']=True
        ops.append(op);installed[p]=after
    for p,(blob,mode) in targets(files).items():add(p,blob,mode)
    for p,target in links().items():
        after=dict(kind='link',target=target);ops.append(dict(path=p,before=facts['paths'][p],after=after));installed[p]=after
    for p in LISTS:
        sections=['Whitelist','WhitelistExitSuccess'] if 'recmgr' in p else ['Whitelist']
        add(p,edit_list(facts['lists'][p],sections,VERSIONS).encode(),facts['paths'][p]['mode'],facts['paths'][p])
    add(CARPLAY,patched,facts['paths'][CARPLAY]['mode'],facts['paths'][CARPLAY])
    state=dict(owner=ID,version=selection(root,[ID])[0]['version'],bundle=checked['bundle'],boot=facts['boot'],backupId=backup.name,
               originalSha256=sha(original),patchedSha256=sha(patched),installed=installed)
    add(STATE,json.dumps(state,indent=2).encode(),0o600)
    plan=dict(action='install',boot=facts['boot'],carplayHash=sha(original),allowed=list(facts['paths']),ops=ops)
    (backup/'map-install-plan.json').write_text(json.dumps(plan,indent=2))
    log('Installing Apple Maps in KOMBI. Renderer files and CarPlay patch only; backups stay on this PC.\n')
    send_plan(checked,plan,data,log)
    log('Apple Maps in KOMBI installed — restart HU, reconnect CarPlay and select Map view in the instrument-cluster settings. Live rendering has not yet been verified.\n'
        'Factory direction cards and duplicate speed readouts are separate display settings; this patch does not suppress them.\n')

def remove(root,host,port,key,approve,log):
    import pc_backup
    checked=check(root,host,port,key,approve,log)
    state=checked['state']
    if not state: raise ValueError('Apple Maps in KOMBI is not installed by Studio')
    base=pc_backup.backup_base(root)
    matches=list(base.glob('*/'+state['backupId']+'/files.tar'))
    if len(matches)!=1: raise ValueError('The original PC backup is required to remove the map patch')
    original_backup=matches[0]
    manifest=json.loads((original_backup.parent/'manifest.json').read_text())
    if pc_backup.verify_archive(original_backup,manifest['present'])!=manifest['sha256']:
        raise ValueError('Original PC backup checksum failed')
    facts=checked['facts'];args=[checked[k] for k in ('host','port','key','known')]
    backup=pc_backup.capture(root,*args,[p.lstrip('/') for p in facts['paths']],log,'kombi-maps-remove')
    ops=[];data={}
    with tarfile.open(original_backup,'r:') as t:
        for p in (CARPLAY,*LISTS):
            blob=t.extractfile(p.lstrip('/')).read()
            src='data/'+str(len(data));data[src]=blob;attrs=facts['paths'][p]
            after=file_info(blob,attrs['mode'],attrs['uid'],attrs['gid'])
            if p==CARPLAY and after['sha256']!=state['originalSha256']:raise ValueError('Original CarPlay backup mismatch')
            ops.append(dict(path=p,before=attrs,after=after,src=src))
    # Exact-file removal only. No recursive deletion of shared or system folders.
    for p in [*targets(payload(root)[1]),*links(),STATE]:
        ops.append(dict(path=p,before=facts['paths'][p],after=dict(kind='absent')))
    plan=dict(action='remove',boot=facts['boot'],carplayHash=state['patchedSha256'],allowed=list(facts['paths']),ops=ops)
    (backup/'map-remove-plan.json').write_text(json.dumps(plan,indent=2))
    send_plan(checked,plan,data,log)
    log('Map integration removed. Restart the HU to return to the original CarPlay process.\n')
