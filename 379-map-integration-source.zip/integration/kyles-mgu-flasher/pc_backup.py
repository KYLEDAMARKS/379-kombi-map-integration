"""Existing 379 PC backup functions; unrelated app path lists omitted."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import hashlib, json, re, shlex, tarfile, uuid
import operation_progress

def backup_base(root):
    """Keep the user's chosen PC backup location independent of the app folder."""
    setting=Path(root)/'data/backup-location.json'
    if setting.is_file():
        value=json.loads(setting.read_text(encoding='utf-8'))
        folder=Path(value['path'])
        if not folder.is_absolute():raise ValueError('The PC backup folder must be an absolute path')
        return folder
    return Path(root).parent/'Kyles Mods Backups'


def verify_archive(path, expected):
    """Read every member without extraction; reject truncated or unrelated archives."""
    found=set()
    with tarfile.open(path,mode='r:') as archive:
        for item in archive:
            name=item.name.rstrip('/')
            if PurePosixPath(name).is_absolute() or '..' in PurePosixPath(name).parts:
                raise ValueError('Unsafe path in backup')
            if not any(name==p or name.startswith(p+'/') for p in expected):
                raise ValueError('Unexpected path in backup: '+name)
            found.add(name)
            if item.isfile():
                f=archive.extractfile(item); count=0
                while chunk:=f.read(1024*1024): count+=len(chunk)
                if count!=item.size: raise ValueError('Truncated backup member: '+name)
    if not set(expected)<=found: raise ValueError('Backup is missing requested paths')
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        while chunk:=f.read(1024*1024): h.update(chunk)
    return h.hexdigest()


def capture(root, host, port, key, known, paths, log, operation='apps'):
    import mod_install
    progress=operation_progress.current()
    progress.stage('Preparing PC backup','Reading the requested paths. No backup files are written on the HU.')
    paths=list(dict.fromkeys(paths))
    if not paths or any(not re.fullmatch(r'[A-Za-z0-9_./-]+',p) or p.startswith('/') or '..' in p.split('/') for p in paths):
        raise ValueError('Invalid backup paths')
    # Only lstat the declared paths. Nothing is copied or written on the HU.
    script="const fs=require('fs');const paths=JSON.parse(process.argv[2]);process.stdout.write(JSON.stringify(paths.filter(p=>{try{fs.lstatSync('/'+p);return true;}catch(e){if(e.code==='ENOENT')return false;throw e;}})));"
    output=mod_install.ssh(host,port,key,known,'node - '+shlex.quote(json.dumps(paths)),data=script.encode(),timeout=30)
    present=json.loads(output)
    if not isinstance(present,list) or not present or set(present)-set(paths): raise ValueError('Invalid backup path response')
    try: vin=json.loads((Path(root)/'data/connection.json').read_text()).get('vin','')
    except (OSError,ValueError): vin=''
    if not re.fullmatch('[A-HJ-NPR-Z0-9]{17}',vin): vin=host.replace('.','-')+'-'+str(port)
    folder=backup_base(root)/vin/(datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')+'-'+operation+'-'+uuid.uuid4().hex[:8])
    folder.mkdir(parents=True,exist_ok=False)
    partial=folder/'files.tar.partial'
    log('Saving backup directly to PC: '+str(folder)+'\n')
    progress.stage('Downloading HU backup','Streaming files directly to this PC. The HU does not report an archive size in advance.',unit='bytes')
    mod_install.ssh_download(host,port,key,known,'tar cpf - -C / -T -',partial,
                             data=('\n'.join(present)+'\n').encode(),timeout=600)
    progress.stage('Verifying PC backup','Reading every archive member and calculating SHA-256 on this PC.')
    checksum=verify_archive(partial,present)
    archive=folder/'files.tar'; partial.replace(archive)
    (folder/'SHA256.txt').write_text(checksum+'  files.tar\n')
    # ACL output is streamed too; never create a permissions file on the HU.
    command='if command -v getfacl >/dev/null; then getfacl -R -p '+' '.join(shlex.quote('/'+p) for p in present)+'; fi'
    progress.stage('Saving file permissions','Streaming the permission record to this PC.',unit='bytes')
    mod_install.ssh_download(host,port,key,known,command,folder/'permissions.acl',timeout=120)
    (folder/'manifest.json').write_text(json.dumps({'operation':operation,'host':host,'port':port,
        'requested':paths,'present':present,'missing':[p for p in paths if p not in present],
        'sha256':checksum,'verified':True,'scope':'Requested HU files only; not a full firmware or CAFD coding backup'},indent=2))
    log('PC backup verified. No backup archive was written to the HU.\n')
    return folder

