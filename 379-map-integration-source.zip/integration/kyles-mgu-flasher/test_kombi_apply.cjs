// Run the actual HU script against an in-memory filesystem. Never touches a car.
const vm=require('vm'),crypto=require('crypto'),path=require('path'),assert=require('assert');
const source=require('fs').readFileSync(0,'utf8');
const digest=b=>crypto.createHash('sha256').update(b).digest('hex');
function scenario(kind){
 const loader='/lib/ld-linux-x86-64.so.2';
 const original=Buffer.from('original carplay'),replacement=Buffer.alloc(256);
 replacement.write('7f454c46',0,'hex');replacement[4]=2;replacement[5]=1;replacement.writeUInt16LE(62,18);
 replacement.writeUInt32LE(64,32);replacement.writeUInt16LE(56,54);replacement.writeUInt16LE(1,56);
 replacement.writeUInt32LE(3,64);replacement.writeUInt32LE(128,72);replacement.writeUInt32LE(loader.length+1,96);replacement.write(loader,128);
 if(kind==='badelf')replacement[4]=1;
 if(kind==='badloader')replacement.write('/tmp/evil-loader',128);
 const attrs=b=>({kind:'file',sha256:digest(b),mode:493,uid:0,gid:0});
 const plan={action:'install',boot:'test-boot',carplayHash:digest(original),allowed:['/usr/bin/carplay'],ops:[{path:'/usr/bin/carplay',before:attrs(original),after:attrs(replacement),src:'data/0',executable:true}]};
 if(kind==='ok'){
  const target='/var/opt/waze-on-cluster/versions/test/waze-on-cluster';
  plan.allowed.push(target);plan.ops.push({path:target,before:{kind:'absent'},after:attrs(replacement),src:'data/0',executable:true});
 }
 const data=new Map(),dirs=new Set(['/','/usr','/usr/bin','/tmp','/proc','/proc/sys','/proc/sys/kernel','/proc/sys/kernel/random']),dirModes=new Map(),calls=[],writes=[];
 function put(p,b,mode=493){data.set(p,{data:Buffer.from(b),mode,uid:0,gid:0});}
 put('plan.json',JSON.stringify(plan));put('data/0',kind==='checksum'?'tampered':replacement);
 put('/usr/bin/carplay',kind==='race'?'changed by another app':original);
 put('/proc/sys/kernel/random/boot_id','test-boot');put('/proc/mounts','/dev/root / ext4 ro,relatime 0 0\n');
 if(kind!=='noloader')put(loader,'system loader');
 const error=code=>Object.assign(Error(code),{code});
 let fd=0;const fds=new Map();
 const fs={
  existsSync:p=>data.has(p)||dirs.has(p),
  lstatSync(p){if(dirs.has(p))return{isDirectory:()=>true,isSymbolicLink:()=>false,isFile:()=>false};const e=data.get(p);if(!e)throw error('ENOENT');return{...e,isDirectory:()=>false,isSymbolicLink:()=>!!e.target,isFile:()=>!e.target};},
  readFileSync(p,enc){const e=data.get(p);if(!e)throw error('ENOENT');return enc?e.data.toString():Buffer.from(e.data);},
  writeFileSync(p,b,opt={}){if(opt.flag==='wx'&&data.has(p))throw error('EEXIST');put(p,b,opt.mode);writes.push(p);},
  chmodSync(p,m){if(dirs.has(p))dirModes.set(p,m);else data.get(p).mode=m;},chownSync(p,u,g){Object.assign(data.get(p),{uid:u,gid:g});},
  openSync(p,flags,mode){if(flags==='wx'){if(data.has(p))throw error('EEXIST');put(p,'',mode);}else if(!data.has(p))throw error('ENOENT');fds.set(++fd,p);return fd;},
  closeSync(f){fds.delete(f);},fsyncSync(){},
  unlinkSync(p){if(!data.delete(p))throw error('ENOENT');},
  renameSync(a,b){if(kind==='rename'&&b==='/usr/bin/carplay')throw error('EBUSY');data.set(b,data.get(a));data.delete(a);},
  mkdirSync(p,mode){dirs.add(p);dirModes.set(p,mode&~0o077);},rmdirSync(p){dirs.delete(p);},
  readlinkSync(p){return data.get(p).target;},symlinkSync(t,p){data.set(p,{target:t});}
 };
 const process={pid:234,getuid:()=>0,exitCode:0,stdout:{write:s=>calls.push(['stdout',s])},stderr:{write:s=>calls.push(['stderr',s])}};
 const cp={execFileSync(cmd,args){calls.push([cmd,args]);assert.notEqual(cmd,'ldd','HU has no ldd');if(cmd===loader){assert.equal(args[0],'--list');if(kind==='loadererror')throw Object.assign(Error('exit 1'),{stderr:'GLIBC_9.9 not found'});return kind==='library'?'libmystery.so => not found':'libc.so => /lib/libc.so';}if(cmd==='df')return'Filesystem 1024-blocks Used Available Capacity Mounted\n/dev/root 100000 10000 90000 10% /\n';return '';}};
 vm.runInNewContext(source,{require:n=>({fs,path,crypto,child_process:cp})[n],process,Buffer,Set,console});
 assert(!calls.some(c=>c[0]==='systemctl'||c[0]==='reboot'),'No activation or reboot');
 assert(!writes.some(p=>/backup|woc-orig/.test(p)),'No HU backups');
 if(kind==='ok'){
  assert.equal(process.exitCode,0);assert(data.get('/usr/bin/carplay').data.equals(replacement));
  assert(calls.some(c=>c[0]==='stdout'&&c[1].includes('MAPS_FILES_VERIFIED')));
  for(const p of ['/var','/var/opt','/var/opt/waze-on-cluster','/var/opt/waze-on-cluster/versions','/var/opt/waze-on-cluster/versions/test'])
   assert.equal(dirModes.get(p),0o755,'Service user must traverse '+p+' despite SSH umask 077');
 }else{
  assert.equal(process.exitCode,1);assert(!calls.some(c=>c[0]==='stdout'&&c[1].includes('MAPS_FILES_VERIFIED')));
  assert(data.get('/usr/bin/carplay').data.equals(kind==='race'?Buffer.from('changed by another app'):original));
  assert(calls.some(c=>c[0]==='stderr'&&c[1].includes('No map files were replaced.')));
  assert(!calls.some(c=>c[0]==='stderr'&&c[1].includes('Restore the changed')));
 }
 const mounts=calls.filter(c=>c[0]==='mount');
 if(kind==='ok'||kind==='rename')assert.deepEqual(mounts.map(c=>c[1][1]),['remount,rw','remount,ro']);
 else assert.equal(mounts.length,0);
 assert(!data.has('/tmp/studio-kombi-maps.lock'));
}
for(const kind of ['ok','race','checksum','rename','library','noloader','badelf','badloader','loadererror'])scenario(kind);
console.log('PASS: native loader without ldd, dependency and ELF failures, file race, tampering, atomic rename failure; no reboot; root mount restored');
