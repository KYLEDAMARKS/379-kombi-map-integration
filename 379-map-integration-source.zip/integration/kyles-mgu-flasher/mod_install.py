"""Existing 379 SSH functions; unrelated app installation omitted."""
from pathlib import Path
import base64, hashlib, ipaddress, json, os, shutil, socket, subprocess, uuid
import operation_progress, transfer_process
from quiet_process import install as quiet_helpers
from mgu7.sshcli import prepared_key
from mod_package import atomic_write
quiet_helpers()

def endpoint(host, port):
    host = str(ipaddress.IPv4Address(host.strip()))
    port = int(port)
    if not 1 <= port <= 65535: raise ValueError('Invalid SSH port')
    return host, port


def executable(name):
    binary = shutil.which(name)
    if not binary and os.name=='nt':
        candidate = Path(os.environ.get('WINDIR','C:/Windows'))/'System32/OpenSSH'/f'{name}.exe'
        if candidate.is_file(): binary = str(candidate)
    if not binary: raise ValueError('Windows OpenSSH Client is required (same dependency as the original flasher)')
    return binary


def invoke(argv, *, data=None, timeout=60, on_bytes=None, on_line=None):
    if on_bytes or on_line:
        return transfer_process.run(argv,data=data,timeout=timeout,on_bytes=on_bytes,on_line=on_line)
    try:
        result = subprocess.run(argv, input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                timeout=timeout, creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError('SSH timed out; outcome is unknown. Inspect the log/head unit before retrying.') from exc
    text = result.stdout.decode('utf-8','replace')
    error = result.stderr.decode('utf-8','replace')
    if result.returncode:
        raise RuntimeError(text+'\n'+error+f'\nSSH exit {result.returncode}')
    return text


def check_ssh_route(host, port):
    """Only check TCP reachability; never send a command or claim SSH login."""
    host,port=endpoint(host,port)
    try:
        with socket.create_connection((host,port),timeout=5): pass
    except OSError as exc:
        address=ipaddress.IPv4Address(host)
        hint=('This is the car-side link-local address. For a remote car, the helper must provide an SSH tunnel '
              'to the MGU port 22; enter that tunnel\'s local address and port as the override.'
              if address.is_link_local else
              'Check that the local SSH tunnel is running and forwards to the intended MGU port 22.'
              if address.is_loopback else
              'Check the route to this address, the SSH port, and whether the head unit is awake and listening.')
        raise RuntimeError(f'Cannot reach SSH at {host}:{port}. {hint}\n'
                           'ENET flashing uses a separate connection. A debug-enabled flag does not confirm SSH reachability.\n'
                           f'Network error: {exc}') from exc


def trust_host(root, host, port, approve, log=lambda _:None):
    """Pin a scanned key; automatic rotation requires an explicit local preference."""
    host,port = endpoint(host,port)
    check_ssh_route(host,port)
    token = host if port==22 else f'[{host}]:{port}'
    known = Path(root)/'data/mods_known_hosts'
    try:
        automatic=json.loads((Path(root)/'data/connection.json').read_text(encoding='utf-8')).get('auto_trust_keys') is True
    except (OSError,ValueError,AttributeError): automatic=False
    previous=known.read_text(encoding='utf-8') if known.is_file() else ''
    old_lines=previous.splitlines()
    if not automatic and any(line.split(' ',1)[0]==token for line in old_lines):
        return known
    try:
        scan = invoke([executable('ssh-keyscan'),'-T','5','-p',str(port),'-t','ed25519,rsa',host], timeout=15)
    except RuntimeError as exc:
        raise RuntimeError(f'TCP connected to {host}:{port}, but SSH host-key discovery failed. '
                           'Verify this endpoint reaches the MGU SSH service, not the diagnostic gateway.\n'+str(exc)) from exc
    keys = []
    for line in scan.splitlines():
        parts = line.split()
        if len(parts)==3 and not line.startswith('#') and parts[0]==token and parts[1] in {'ssh-ed25519','ssh-rsa'}:
            decoded = base64.b64decode(parts[2], validate=True)
            fingerprint = 'SHA256:'+base64.b64encode(hashlib.sha256(decoded).digest()).decode().rstrip('=')
            keys.append((parts[1], line, fingerprint))
    if not keys: raise RuntimeError('SSH did not return a supported host key')
    keys.sort(key=lambda k:k[0]!='ssh-ed25519')
    keytype,line,fingerprint = keys[0]
    if line in old_lines: return known
    if not automatic and not approve(f'{host}:{port}\n{keytype}\n{fingerprint}\n\nVerify this fingerprint belongs to the intended MGU before trusting it.'):
        raise RuntimeError('Host key was not trusted; no apps uploaded')
    known.parent.mkdir(parents=True,exist_ok=True)
    if previous:
        atomic_write(known.with_name('mods_known_hosts.previous-'+uuid.uuid4().hex),previous.encode('utf-8'))
    retained=[entry for entry in old_lines if entry.split(' ',1)[0]!=token]
    atomic_write(known,('\n'.join(retained+[line])+'\n').encode('utf-8'))
    log(f'SSH host key saved for {host}:{port}: {fingerprint}'+
        (' (automatic trust enabled).\n' if automatic else '.\n'))
    return known


def ssh(host, port, key, known, command, *, data=None, timeout=60, on_bytes=None, on_line=None):
    host,port = endpoint(host,port)
    if not Path(key).is_file(): raise ValueError('Select this car\'s SSH private key')
    with prepared_key(str(key)) as private_key:
        argv = [executable('ssh'),'-F','none','-i',private_key,'-p',str(port),
                '-o','BatchMode=yes','-o','StrictHostKeyChecking=yes',
                '-o',f'UserKnownHostsFile="{Path(known).resolve().as_posix()}"',
                '-o','GlobalKnownHostsFile='+os.devnull,'-o','IdentitiesOnly=yes',
                '-o','ConnectTimeout=15','-o','ServerAliveInterval=10','-o','ServerAliveCountMax=3',
                f'root@{host}',command]
        return invoke(argv,data=data,timeout=timeout,on_bytes=on_bytes,on_line=on_line)


def ssh_download(host, port, key, known, command, destination, *, data=None, timeout=600):
    """Binary stdout goes straight to disk; never buffer a backup in memory."""
    host,port=endpoint(host,port)
    if not Path(key).is_file(): raise ValueError('Select this car\'s SSH private key')
    with prepared_key(str(key)) as private_key,Path(destination).open('wb') as output:
        argv=[executable('ssh'),'-F','none','-i',private_key,'-p',str(port),
              '-o','BatchMode=yes','-o','StrictHostKeyChecking=yes',
              '-o',f'UserKnownHostsFile="{Path(known).resolve().as_posix()}"',
              '-o','GlobalKnownHostsFile='+os.devnull,'-o','IdentitiesOnly=yes',
              '-o','ConnectTimeout=15','-o','ServerAliveInterval=10','-o','ServerAliveCountMax=3',
              f'root@{host}',command]
        progress=operation_progress.current()
        transfer_process.run(argv,data=data,timeout=timeout,destination=output,
                             on_bytes=lambda count,total:progress.update(completed=count))

