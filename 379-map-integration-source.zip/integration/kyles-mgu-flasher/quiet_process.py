"""Hide Windows console helpers without changing their commands or results."""
import os
import subprocess


def options(kwargs=None):
    result = dict(kwargs or {})
    if os.name == 'nt':
        result['creationflags'] = result.get('creationflags', 0) | subprocess.CREATE_NO_WINDOW
        startup = result.get('startupinfo') or subprocess.STARTUPINFO()
        startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startup.wShowWindow = subprocess.SW_HIDE
        result['startupinfo'] = startup
    return result


class QuietSubprocess:
    """Module-local adapter: do not monkey-patch Python's global subprocess module."""
    def __getattr__(self, name): return getattr(subprocess, name)
    def run(self, *args, **kwargs): return subprocess.run(*args, **options(kwargs))
    def Popen(self, *args, **kwargs): return subprocess.Popen(*args, **options(kwargs))


def install():
    from mgu7 import sshcli
    sshcli.subprocess = QuietSubprocess()
