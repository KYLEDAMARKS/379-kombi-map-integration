# Extracted unchanged prepared_key function. Original toolkit: Unlicense.
import contextlib, os, subprocess, tempfile, uuid

@contextlib.contextmanager
def prepared_key(key_path):
    """Yield a key path the OpenSSH client will accept, cleaning it up after.

    OpenSSH refuses a private key other accounts can read ('UNPROTECTED PRIVATE
    KEY FILE'). On Windows a key under the user's Desktop usually inherits an
    ACL that grants the Users group read, which trips that check. We copy the
    key into a fresh temp file, lock it to the current user only, hand that to
    ssh, and delete it afterwards so no key copy lingers."""
    try:
        with open(key_path, 'rb') as f:
            data = f.read()
    except OSError:
        yield key_path  # let ssh report the real error
        return
    tmp = os.path.join(tempfile.gettempdir(), 'mgu_id_' + uuid.uuid4().hex)
    try:
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
    except OSError:
        try:
            os.remove(tmp)
        except OSError:
            pass
        yield key_path
        return
    try:
        if os.name == 'nt':
            user = os.environ.get('USERNAME') or os.environ.get('USER') or ''
            if user:
                # Grant the owner full control, then drop every inherited ACE
                # (Users/Authenticated Users). Final DACL = this user only,
                # which satisfies OpenSSH and still lets us rewrite/delete.
                subprocess.run(['icacls', tmp, '/grant:r', '%s:F' % user],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                subprocess.run(['icacls', tmp, '/inheritance:r'],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            os.chmod(tmp, 0o600)
        yield tmp
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass

