"""Stream OpenSSH transfers with bounded logs, concurrent drains and hard timeouts."""
import subprocess
import threading
import time
from quiet_process import options


def run(argv, *, data=None, timeout=60, on_bytes=None, on_line=None, destination=None):
    errors, output, stderr = [], bytearray(), bytearray()
    limit = 2 * 1024 * 1024
    def tail(buffer, chunk):
        buffer.extend(chunk)
        if len(buffer) > limit: del buffer[:-limit]
    def guarded(fn):
        try: fn()
        except Exception as exc: errors.append(exc)
    with subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, **options()) as process:
        def write():
            try:
                blob = memoryview(data or b'')
                for offset in range(0, len(blob), 32768):
                    part = blob[offset:offset+32768]
                    process.stdin.write(part)
                    process.stdin.flush()
                    if on_bytes and destination is None: on_bytes(offset+len(part), len(blob))
            finally: process.stdin.close()
        def read():
            count, pending = 0, bytearray()
            while chunk := process.stdout.read1(65536):
                count += len(chunk)
                if destination is not None:
                    destination.write(chunk)
                    if on_bytes: on_bytes(count, None)
                else:
                    tail(output, chunk)
                    if on_line:
                        pending.extend(chunk)
                        while b'\n' in pending:
                            line, _, rest = pending.partition(b'\n'); pending[:] = rest
                            on_line(line.decode('utf-8', 'replace')+'\n')
                        if len(pending) > 65536:
                            on_line(pending.decode('utf-8', 'replace')); pending.clear()
            if pending and on_line: on_line(pending.decode('utf-8', 'replace'))
        def read_error():
            while chunk := process.stderr.read1(65536): tail(stderr, chunk)
        threads = [threading.Thread(target=lambda f=f: guarded(f), daemon=True) for f in (write, read, read_error)]
        for thread in threads: thread.start()
        try:
            deadline=time.monotonic()+timeout
            while process.poll() is None:
                if errors:
                    process.kill();process.wait()
                    raise RuntimeError('Transfer stopped: '+str(errors[0])) from errors[0]
                remaining=deadline-time.monotonic()
                if remaining<=0: raise subprocess.TimeoutExpired(argv,timeout)
                try:process.wait(timeout=min(.1,remaining))
                except subprocess.TimeoutExpired:pass
        except subprocess.TimeoutExpired:
            process.kill(); process.wait()
            raise RuntimeError('SSH timed out; outcome is unknown. Read HU before retrying.')
        finally:
            for thread in threads: thread.join()
        text = output.decode('utf-8', 'replace')
        if process.returncode:
            raise RuntimeError(text+'\n'+stderr.decode('utf-8', 'replace')+f'\nSSH exit {process.returncode}')
        if errors: raise RuntimeError('Transfer did not finish: '+str(errors[0])) from errors[0]
        return text
