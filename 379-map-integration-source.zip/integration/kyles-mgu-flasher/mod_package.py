"""Map packaging functions extracted unchanged from 379; unrelated app exporting omitted."""
from pathlib import Path
import hashlib, io, json, os, re, tarfile, tempfile

def digest(data):
    return hashlib.sha256(data).hexdigest()


def load_catalog(root):
    items = json.loads((Path(root)/'payload/catalog.json').read_text(encoding='utf-8'))
    seen = set()
    for item in items:
        if not re.fullmatch(r'[a-z][a-z0-9_]*', item['id']) or item['id'] in seen:
            raise ValueError('Invalid or duplicate app ID')
        seen.add(item['id'])
        expected = item['id']+'@'+item['version']+'.mgu'
        if item['filename'] != expected or Path(expected).name != expected or '/' in expected or '\\' in expected:
            raise ValueError('Invalid app filename')
        if not re.fullmatch('[0-9a-f]{64}', item['sha256']):
            raise ValueError('Invalid checksum')
    if not items:
        raise ValueError('No apps are packaged with this program')
    return items


def selection(root, app_ids):
    catalog = load_catalog(root)
    wanted = set(app_ids)
    if not wanted:
        raise ValueError('Select at least one app')
    if wanted - {i['id'] for i in catalog}:
        raise ValueError('Selection includes an app that is not in this package')
    return [i for i in catalog if i['id'] in wanted]


def checked_file(root, relative, checksum):
    root = Path(root).resolve()
    file = (root/relative).resolve()
    if not file.is_relative_to(root) or not file.is_file():
        raise ValueError('Payload path is outside the program folder or missing')
    data = file.read_bytes()
    if digest(data) != checksum:
        raise ValueError('Checksum mismatch: '+str(relative))
    return data


def app_data(root, item):
    data = checked_file(root, 'payload/apps/'+item['filename'], item['sha256'])
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as tar:
        metadata = json.load(tar.extractfile('meta.json'))
        if any(metadata.get(k) != item[k] for k in ['id','title','version']):
            raise ValueError('Bundle metadata differs from catalog: '+item['id'])
    return data


def atomic_write(destination, data):
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.package-', dir=destination.parent)
    try:
        with os.fdopen(fd, 'wb') as file: file.write(data)
        os.replace(temporary, destination)
    finally:
        if os.path.exists(temporary): os.unlink(temporary)

