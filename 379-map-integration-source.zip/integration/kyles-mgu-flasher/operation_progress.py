"""Console release uses the original no-UI progress interface."""
class _Quiet:
    def stage(self, *args, **kwargs): pass
    def update(self, **kwargs): pass


def current(): return _Quiet()
