// Exact map-view function extracted from 379; host supplies cv, text, fit, C, add, changed and carplay.
 function carplayView(cv){
   if(Date.now()-mapPollAt>5000){mapPollAt=Date.now();carplay.refresh().then(changed);}
   const s=carplay.snapshot();text(cv,'Apple Maps & Waze',226,34,26,C.text,true);
   text(cv,'Connect iPhone CarPlay, then open Apple Maps or Waze.',226,87,23,C.dim);
   [[226,'HEAD UNIT','Primary CarPlay display'],[906,'KOMBI','Dark map behind the instruments']].forEach(([x,title,sub],i)=>{
     cv.roundRect(x,115,654,239,14,C.panel);text(cv,title,x+22,149,17,C.blue,true);text(cv,sub,x+22,180,22,C.text);
     cv.roundRect(x+24,203,606,124,12,'#080c13');
     if(s.preview&&(i===0||s.enabled)){
       for(let k=0;k<4;k++)cv.line(x+48+k*130,213,x+106+k*130,315,2,'#25364a');
       cv.line(x+36,270,x+615,240,7,'#26374c');cv.line(x+210,308,x+315,255,4,C.blue);cv.line(x+315,255,x+455,249,4,C.blue);
       text(cv,s.preview?'DISPLAY PREVIEW':'CarPlay on your head unit',x+44,236,14,C.dim,true);
     }else text(cv,i===0?'Factory CarPlay':s.showing?'Map video active':s.enabled?'Waiting for CarPlay video':'KOMBI map off',x+72,276,27,C.dim);
   });
   cv.roundRect(226,377,1334,82,12,C.panel);text(cv,'Show phone map in KOMBI',248,411,26,C.text,true);
   text(cv,fit(cv,s.reason,950,18),248,440,18,C.dim);
   cv.roundRect(1417,396,112,42,21,s.enabled?C.accent:'#333c4a');cv.circle(s.enabled?1508:1438,417,16,C.text);
   text(cv,s.busy?'CHECKING':s.available?(s.enabled?'ON':'OFF'):'UNAVAILABLE',s.available?1337:1218,425,18,s.available?C.text:C.dim,true);
   add('carplay-toggle',1200,377,360,82,async()=>{await carplay.set(!s.enabled);},s.available);
   text(cv,'Requires the KOMBI add-on and a map video stream from the iPhone app.',226,494,18,C.dim);
   text(cv,'Waze uses this same CarPlay route. Reconnect the iPhone if video is waiting.',226,526,18,C.dim);
 }
