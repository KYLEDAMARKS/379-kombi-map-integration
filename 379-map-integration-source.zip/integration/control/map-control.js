'use strict';
// Bounded local API: controls the separately installed Studio map service only.
// Never patches firmware, restarts CarPlay, or accepts shell text or paths.
const fs=require('fs'),net=require('net'),cp=require('child_process'),crypto=require('crypto');
const UNITS=['waze-on-cluster.socket','waze-on-cluster.service'];
function execute(args){return new Promise((ok,fail)=>cp.execFile('/bin/systemctl',args,{timeout:12000,maxBuffer:16384},(e,out)=>e?fail(Error('Map service: '+(e.message||e))):ok(out.trim())));}
function installed(){
 const s=JSON.parse(fs.readFileSync('/var/opt/kyles-maps-kombi/state.json','utf8'));
 if(s.owner!=='apple_maps_kombi'||!s.installed)throw Error('Install Apple Maps in KOMBI with Studio first');
 const hash=crypto.createHash('sha256').update(fs.readFileSync('/usr/bin/carplay')).digest('hex');
 if(hash!==s.patchedSha256)throw Error('CarPlay firmware differs from the installed add-on');
 for(const unit of UNITS){const name='/etc/systemd/system/'+unit,expected=s.installed[name];
  if(!expected||expected.kind!=='file'||crypto.createHash('sha256').update(fs.readFileSync(name)).digest('hex')!==expected.sha256)
    throw Error('Map service changed: check the add-on in Studio');}
 return s;
}
function fileState(){try{const p='/run/waze-on-cluster/status.json';if(Date.now()-fs.statSync(p).mtimeMs>5000)return null;return JSON.parse(fs.readFileSync(p,'utf8'));}catch(e){return null;}}
function createHandler(deps){
 const run=deps.execute,verify=deps.installed,read=deps.fileState;let busy=false;
 return async function(msg){
  if(!msg||!['status','set'].includes(msg.cmd)||(msg.cmd==='set'&&typeof msg.enabled!=='boolean'))throw Error('Unsupported request');
  if(busy)throw Error('Map command in progress');busy=true;
  try{
   verify();
   if(msg.cmd==='set')await run([msg.enabled?'start':'stop'].concat(UNITS));
   let active=false;try{active=(await run(['is-active','waze-on-cluster.service']))==='active';}catch(e){}
   if(msg.cmd==='set'&&active!==msg.enabled)throw Error('Map service did not reach the requested state');
   const s=active?read():null;
   return {available:true,enabled:active,showing:!!(s&&s.state==='showing'&&s.target==='map'),state:s?s.state:active?'waiting':'off',
    reason:active?(s&&s.reason||'Reconnect CarPlay and open Apple Maps; waiting for video'):'KOMBI map off; factory CarPlay stays on the head unit'};
  }finally{busy=false;}
 };
}
if(require.main===module){
 const handle=createHandler({execute,installed,fileState});
 const server=net.createServer(s=>{let buf='',done=false;s.setTimeout(15000,()=>s.destroy());
  s.on('error',()=>{});s.on('data',d=>{if(done)return;buf+=d.toString('utf8');if(buf.length>512){s.destroy();return;}
   if(buf.indexOf('\n')<0)return;done=true;
   Promise.resolve().then(()=>handle(JSON.parse(buf.split('\n')[0]))).then(r=>s.end(JSON.stringify(r)+'\n'),e=>s.end(JSON.stringify({available:false,enabled:false,showing:false,reason:e.code==='ENOENT'?'Install Apple Maps in KOMBI with Studio first':e.message})+'\n'));
  });
 });
 // systemd owns the socket and its permissions; no TCP listener.
 server.listen({fd:3});
}
module.exports={createHandler};
