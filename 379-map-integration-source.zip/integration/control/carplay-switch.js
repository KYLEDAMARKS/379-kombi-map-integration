'use strict';
function request(message){return new Promise((resolve,reject)=>{
 const s=require('net').createConnection('/run/379-control/control.sock');let buffer='',done=false;
 const finish=(error,value)=>{if(done)return;done=true;s.destroy();error?reject(error):resolve(value);};
 s.setTimeout(14000,()=>finish(Error('KOMBI helper timed out')));
 s.on('error',e=>finish(Error(e.code==='ENOENT'?'Update 379 through Studio to install its control helper':e.message)));
 s.on('connect',()=>s.write(JSON.stringify(message)+'\n'));
 s.on('data',d=>{buffer+=d.toString('utf8');if(buffer.length>8192)return finish(Error('Invalid helper reply'));
  if(buffer.indexOf('\n')>=0)try{const r=JSON.parse(buffer.split('\n')[0]);if(typeof r.available!=='boolean'||typeof r.enabled!=='boolean')throw Error('Invalid helper status');finish(null,r);}catch(e){finish(e);}});
 s.on('end',()=>{if(!done)finish(Error('KOMBI helper disconnected'));});
});}
class CarPlaySwitch {
 constructor(simulation,transport){this.simulation=simulation===true;this.request=transport||request;this.busy=false;this.at=0;
  this.status={available:this.simulation,enabled:false,showing:false,state:'off',reason:this.simulation?'Simulator only':'Checking installed KOMBI add-on…'};}
 async refresh(){if(this.simulation||this.busy)return;this.busy=true;try{this.status=await this.request({cmd:'status'});this.at=Date.now();}
  catch(e){this.status={available:false,enabled:false,showing:false,state:'unavailable',reason:e.message};}finally{this.busy=false;}}
 async set(on){if(this.busy)return false;this.busy=true;
  try{if(this.simulation){this.status={available:true,enabled:!!on,showing:false,state:on?'preview':'off',reason:'Simulator only — no vehicle video'};return true;}
   this.status=await this.request({cmd:'set',enabled:!!on});this.at=Date.now();return this.status.available&&this.status.enabled===!!on;
  }catch(e){this.status={available:false,enabled:false,showing:false,state:'unavailable',reason:e.message};return false;}finally{this.busy=false;}}
 snapshot(){return Object.assign({},this.status,{busy:this.busy,available:this.status.available&&!this.busy,preview:this.simulation});}
}
module.exports={CarPlaySwitch};
